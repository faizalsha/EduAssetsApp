package com.example.krishbhatia.eduassets;

public class Constants {
    public static final String USER_ID ="USER_ID" ;
    public static final String NOT_FOUND = "NOT_FOUND";
    public static final String EMAIL ="EMAIL" ;
}
