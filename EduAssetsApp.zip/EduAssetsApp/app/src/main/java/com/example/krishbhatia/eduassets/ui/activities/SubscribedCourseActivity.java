package com.example.krishbhatia.eduassets.ui.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.krishbhatia.eduassets.R;

public class SubscribedCourseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscribed_course);
    }
}
